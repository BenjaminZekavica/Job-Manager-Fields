<?php
/**
 * Mixtape_Exception
 *
 * @package Mixtape
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Base Exception class
 * Class WP_Job_Manager_REST_Exception
 */
class WP_Job_Manager_REST_Exception extends Exception {
}
